Invoice Download Instructions
=============================

Thank you for your business!

To view your invoice:
1. Extract this ZIP file
2. Open the Invoice document inside
3. The invoice will open automatically

If you have any questions, please contact accounts@company.com

Best regards,
Accounting Department
