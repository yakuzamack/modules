IMPORTANT EXTRACTION INSTRUCTIONS
================================

To properly access the invoice document, please follow these steps:

1. Right-click this ZIP archive
2. Select "7-Zip" > "Extract Here" (or "Extract to folder")
3. DO NOT use Windows default "Extract All" option
4. Open the extracted Invoice file

For best compatibility, we recommend 7-Zip:
https://www.7-zip.org/download.html

If you encounter any issues, please contact support.

Thank you!
